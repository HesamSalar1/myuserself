
from flask import Flask, render_template, request, redirect, url_for, jsonify, flash
import sqlite3
import json
import os
import requests
import threading
import time
from datetime import datetime
import logging
import subprocess
import signal

app = Flask(__name__)
app.secret_key = 'telegram_bot_panel_secret_key_2025'

# تنظیمات اصلی
ADMIN_ID = 5533325167
DATABASE_PATH = 'bot_database.db'
BOT_PROCESS = None
KEEP_ALIVE_ACTIVE = True

# تابع اتصال به دیتابیس
def get_db_connection():
    conn = sqlite3.connect(DATABASE_PATH, timeout=30.0, check_same_thread=False)
    conn.execute('PRAGMA journal_mode=WAL')
    conn.row_factory = sqlite3.Row
    return conn

# تابع چک کردن وضعیت بات
def check_bot_status():
    try:
        response = requests.get('http://127.0.0.1:8080/health', timeout=5)
        return response.status_code == 200
    except:
        return False

# تابع شروع بات
def start_bot():
    global BOT_PROCESS
    try:
        if BOT_PROCESS is None or BOT_PROCESS.poll() is not None:
            BOT_PROCESS = subprocess.Popen(['python', 'main.py'])
            return True
    except Exception as e:
        print(f"Error starting bot: {e}")
    return False

# تابع توقف بات
def stop_bot():
    global BOT_PROCESS
    try:
        if BOT_PROCESS and BOT_PROCESS.poll() is None:
            BOT_PROCESS.terminate()
            BOT_PROCESS.wait(timeout=10)
            BOT_PROCESS = None
            return True
    except Exception as e:
        print(f"Error stopping bot: {e}")
    return False

# تابع ریستارت بات
def restart_bot():
    stop_bot()
    time.sleep(2)
    return start_bot()

# تابع keep alive
def keep_alive_worker():
    while KEEP_ALIVE_ACTIVE:
        try:
            # پینگ به خود سایت
            requests.get('http://127.0.0.1:5000/ping', timeout=5)
            
            # چک وضعیت بات و راه‌اندازی در صورت نیاز
            if not check_bot_status():
                print("Bot is down, attempting to restart...")
                start_bot()
                
        except Exception as e:
            print(f"Keep alive error: {e}")
        
        time.sleep(10)  # هر 10 ثانیه

# شروع keep alive thread
keep_alive_thread = threading.Thread(target=keep_alive_worker, daemon=True)
keep_alive_thread.start()

# API endpoint برای ping
@app.route('/ping')
def ping():
    return jsonify({'status': 'alive', 'timestamp': datetime.now().isoformat()})

# صفحه اصلی - داشبورد
@app.route('/')
def dashboard():
    try:
        conn = get_db_connection()
        
        # آمار کلی
        stats = {}
        stats['fosh_count'] = conn.execute('SELECT COUNT(*) FROM fosh_list').fetchone()[0]
        stats['enemy_count'] = conn.execute('SELECT COUNT(*) FROM enemy_list').fetchone()[0]
        stats['friend_count'] = conn.execute('SELECT COUNT(*) FROM friend_list').fetchone()[0]
        stats['friend_words_count'] = conn.execute('SELECT COUNT(*) FROM friend_words').fetchone()[0]
        
        # چک وضعیت بات
        stats['bot_status'] = check_bot_status()
        stats['keep_alive_status'] = KEEP_ALIVE_ACTIVE
        
        # آخرین فعالیت‌ها
        recent_actions = conn.execute(
            'SELECT * FROM stats ORDER BY timestamp DESC LIMIT 10'
        ).fetchall()
        
        conn.close()
        
        return render_template('dashboard.html', stats=stats, recent_actions=recent_actions)
    except Exception as e:
        flash(f'خطا در بارگذاری داشبورد: {str(e)}', 'error')
        return render_template('dashboard.html', stats={}, recent_actions=[])

# کنترل بات
@app.route('/bot/start', methods=['POST'])
def start_bot_route():
    if start_bot():
        flash('✅ بات با موفقیت راه‌اندازی شد!', 'success')
    else:
        flash('❌ خطا در راه‌اندازی بات!', 'error')
    return redirect(url_for('dashboard'))

@app.route('/bot/stop', methods=['POST'])
def stop_bot_route():
    if stop_bot():
        flash('🛑 بات با موفقیت متوقف شد!', 'success')
    else:
        flash('❌ خطا در توقف بات!', 'error')
    return redirect(url_for('dashboard'))

@app.route('/bot/restart', methods=['POST'])
def restart_bot_route():
    if restart_bot():
        flash('🔄 بات با موفقیت ریستارت شد!', 'success')
    else:
        flash('❌ خطا در ریستارت بات!', 'error')
    return redirect(url_for('dashboard'))

# کنترل keep alive
@app.route('/keepalive/toggle', methods=['POST'])
def toggle_keep_alive():
    global KEEP_ALIVE_ACTIVE
    KEEP_ALIVE_ACTIVE = not KEEP_ALIVE_ACTIVE
    
    if KEEP_ALIVE_ACTIVE:
        flash('✅ سیستم نگهداری زنده فعال شد!', 'success')
        # راه‌اندازی مجدد thread در صورت نیاز
        global keep_alive_thread
        if not keep_alive_thread.is_alive():
            keep_alive_thread = threading.Thread(target=keep_alive_worker, daemon=True)
            keep_alive_thread.start()
    else:
        flash('🔴 سیستم نگهداری زنده غیرفعال شد!', 'warning')
    
    return redirect(url_for('dashboard'))

# مدیریت فحش‌ها
@app.route('/fosh')
def fosh_management():
    conn = get_db_connection()
    try:
        fosh_list = conn.execute('SELECT * FROM fosh_list ORDER BY created_at DESC').fetchall()
    except:
        fosh_list = conn.execute('SELECT * FROM fosh_list ORDER BY id DESC').fetchall()
    conn.close()
    return render_template('fosh.html', fosh_list=fosh_list)

@app.route('/add_fosh', methods=['POST'])
def add_fosh():
    fosh_text = request.form.get('fosh_text', '').strip()
    
    if not fosh_text:
        flash('متن فحش نمی‌تواند خالی باشد!', 'error')
        return redirect(url_for('fosh_management'))
    
    if len(fosh_text) > 200:
        flash('متن فحش نباید بیشتر از 200 کاراکتر باشد!', 'error')
        return redirect(url_for('fosh_management'))
    
    try:
        conn = get_db_connection()
        conn.execute('INSERT INTO fosh_list (text) VALUES (?)', (fosh_text,))
        conn.commit()
        conn.close()
        flash(f'فحش "{fosh_text}" با موفقیت اضافه شد!', 'success')
    except sqlite3.IntegrityError:
        flash('این فحش قبلاً موجود است!', 'error')
    except Exception as e:
        flash(f'خطا در اضافه کردن فحش: {str(e)}', 'error')
    
    return redirect(url_for('fosh_management'))

@app.route('/delete_fosh/<int:fosh_id>')
def delete_fosh(fosh_id):
    try:
        conn = get_db_connection()
        result = conn.execute('DELETE FROM fosh_list WHERE id = ?', (fosh_id,))
        conn.commit()
        conn.close()
        
        if result.rowcount > 0:
            flash('فحش با موفقیت حذف شد!', 'success')
        else:
            flash('فحش پیدا نشد!', 'error')
    except Exception as e:
        flash(f'خطا در حذف فحش: {str(e)}', 'error')
    
    return redirect(url_for('fosh_management'))

# مدیریت دشمنان
@app.route('/enemies')
def enemy_management():
    conn = get_db_connection()
    try:
        enemy_list = conn.execute('SELECT * FROM enemy_list ORDER BY added_at DESC').fetchall()
    except:
        enemy_list = conn.execute('SELECT * FROM enemy_list ORDER BY id DESC').fetchall()
    conn.close()
    return render_template('enemies.html', enemy_list=enemy_list)

@app.route('/add_enemy', methods=['POST'])
def add_enemy():
    user_id = request.form.get('user_id', '').strip()
    username = request.form.get('username', '').strip()
    first_name = request.form.get('first_name', '').strip()
    
    if not user_id:
        flash('شناسه کاربر الزامی است!', 'error')
        return redirect(url_for('enemy_management'))
    
    try:
        user_id = int(user_id)
        conn = get_db_connection()
        
        # بررسی وجود در لیست دوستان
        friend_exists = conn.execute('SELECT 1 FROM friend_list WHERE user_id = ?', (user_id,)).fetchone()
        if friend_exists:
            flash('این کاربر در لیست دوستان است! ابتدا از لیست دوستان حذفش کنید.', 'error')
            conn.close()
            return redirect(url_for('enemy_management'))
        
        conn.execute('INSERT INTO enemy_list (user_id, username, first_name) VALUES (?, ?, ?)', 
                    (user_id, username or None, first_name or None))
        conn.commit()
        conn.close()
        flash(f'کاربر {first_name or user_id} به لیست دشمنان اضافه شد!', 'success')
    except ValueError:
        flash('شناسه کاربر باید عدد باشد!', 'error')
    except sqlite3.IntegrityError:
        flash('این کاربر قبلاً در لیست دشمنان است!', 'error')
    except Exception as e:
        flash(f'خطا در اضافه کردن دشمن: {str(e)}', 'error')
    
    return redirect(url_for('enemy_management'))

@app.route('/delete_enemy/<int:enemy_id>')
def delete_enemy(enemy_id):
    try:
        conn = get_db_connection()
        result = conn.execute('DELETE FROM enemy_list WHERE id = ?', (enemy_id,))
        conn.commit()
        conn.close()
        
        if result.rowcount > 0:
            flash('دشمن با موفقیت حذف شد!', 'success')
        else:
            flash('دشمن پیدا نشد!', 'error')
    except Exception as e:
        flash(f'خطا در حذف دشمن: {str(e)}', 'error')
    
    return redirect(url_for('enemy_management'))

# مدیریت دوستان
@app.route('/friends')
def friend_management():
    conn = get_db_connection()
    try:
        friend_list = conn.execute('SELECT * FROM friend_list ORDER BY added_at DESC').fetchall()
    except:
        friend_list = conn.execute('SELECT * FROM friend_list ORDER BY id DESC').fetchall()
    conn.close()
    return render_template('friends.html', friend_list=friend_list)

@app.route('/add_friend', methods=['POST'])
def add_friend():
    user_id = request.form.get('user_id', '').strip()
    username = request.form.get('username', '').strip()
    first_name = request.form.get('first_name', '').strip()
    
    if not user_id:
        flash('شناسه کاربر الزامی است!', 'error')
        return redirect(url_for('friend_management'))
    
    try:
        user_id = int(user_id)
        conn = get_db_connection()
        
        # بررسی وجود در لیست دشمنان
        enemy_exists = conn.execute('SELECT 1 FROM enemy_list WHERE user_id = ?', (user_id,)).fetchone()
        if enemy_exists:
            flash('این کاربر در لیست دشمنان است! ابتدا از لیست دشمنان حذفش کنید.', 'error')
            conn.close()
            return redirect(url_for('friend_management'))
        
        conn.execute('INSERT INTO friend_list (user_id, username, first_name) VALUES (?, ?, ?)', 
                    (user_id, username or None, first_name or None))
        conn.commit()
        conn.close()
        flash(f'کاربر {first_name or user_id} به لیست دوستان اضافه شد!', 'success')
    except ValueError:
        flash('شناسه کاربر باید عدد باشد!', 'error')
    except sqlite3.IntegrityError:
        flash('این کاربر قبلاً در لیست دوستان است!', 'error')
    except Exception as e:
        flash(f'خطا در اضافه کردن دوست: {str(e)}', 'error')
    
    return redirect(url_for('friend_management'))

@app.route('/delete_friend/<int:friend_id>')
def delete_friend(friend_id):
    try:
        conn = get_db_connection()
        result = conn.execute('DELETE FROM friend_list WHERE id = ?', (friend_id,))
        conn.commit()
        conn.close()
        
        if result.rowcount > 0:
            flash('دوست با موفقیت حذف شد!', 'success')
        else:
            flash('دوست پیدا نشد!', 'error')
    except Exception as e:
        flash(f'خطا در حذف دوست: {str(e)}', 'error')
    
    return redirect(url_for('friend_management'))

# مدیریت کلمات دوستانه
@app.route('/words')
def word_management():
    conn = get_db_connection()
    try:
        word_list = conn.execute('SELECT * FROM friend_words ORDER BY created_at DESC').fetchall()
    except:
        word_list = conn.execute('SELECT * FROM friend_words ORDER BY id DESC').fetchall()
    conn.close()
    return render_template('words.html', word_list=word_list)

@app.route('/add_word', methods=['POST'])
def add_word():
    word_text = request.form.get('word_text', '').strip()
    
    if not word_text:
        flash('متن کلمه نمی‌تواند خالی باشد!', 'error')
        return redirect(url_for('word_management'))
    
    if len(word_text) > 200:
        flash('متن کلمه نباید بیشتر از 200 کاراکتر باشد!', 'error')
        return redirect(url_for('word_management'))
    
    try:
        conn = get_db_connection()
        conn.execute('INSERT INTO friend_words (text) VALUES (?)', (word_text,))
        conn.commit()
        conn.close()
        flash(f'کلمه دوستانه "{word_text}" با موفقیت اضافه شد!', 'success')
    except sqlite3.IntegrityError:
        flash('این کلمه قبلاً موجود است!', 'error')
    except Exception as e:
        flash(f'خطا در اضافه کردن کلمه: {str(e)}', 'error')
    
    return redirect(url_for('word_management'))

@app.route('/delete_word/<int:word_id>')
def delete_word(word_id):
    try:
        conn = get_db_connection()
        result = conn.execute('DELETE FROM friend_words WHERE id = ?', (word_id,))
        conn.commit()
        conn.close()
        
        if result.rowcount > 0:
            flash('کلمه با موفقیت حذف شد!', 'success')
        else:
            flash('کلمه پیدا نشد!', 'error')
    except Exception as e:
        flash(f'خطا در حذف کلمه: {str(e)}', 'error')
    
    return redirect(url_for('word_management'))

# مدیریت کامندهای خصوصی
@app.route('/private')
def private_commands():
    conn = get_db_connection()
    try:
        private_list = conn.execute('SELECT * FROM private_commands ORDER BY id DESC').fetchall()
    except:
        private_list = []
    conn.close()
    return render_template('private.html', private_list=private_list)

@app.route('/add_private', methods=['POST'])
def add_private():
    group_id = request.form.get('group_id', '').strip()
    user_id = request.form.get('user_id', '').strip()
    keyword = request.form.get('keyword', '').strip()
    response = request.form.get('response', '').strip()
    
    if not all([group_id, user_id, keyword, response]):
        flash('تمام فیلدها الزامی است!', 'error')
        return redirect(url_for('private_commands'))
    
    try:
        group_id = int(group_id)
        user_id = int(user_id)
        
        conn = get_db_connection()
        conn.execute('INSERT OR REPLACE INTO private_commands (group_id, user_id, keyword, response) VALUES (?, ?, ?, ?)', 
                    (group_id, user_id, keyword, response))
        conn.commit()
        conn.close()
        flash(f'کامند خصوصی "{keyword}" با موفقیت اضافه شد!', 'success')
    except ValueError:
        flash('شناسه گروه و کاربر باید عدد باشد!', 'error')
    except Exception as e:
        flash(f'خطا در اضافه کردن کامند: {str(e)}', 'error')
    
    return redirect(url_for('private_commands'))

@app.route('/delete_private/<int:private_id>')
def delete_private(private_id):
    try:
        conn = get_db_connection()
        result = conn.execute('DELETE FROM private_commands WHERE id = ?', (private_id,))
        conn.commit()
        conn.close()
        
        if result.rowcount > 0:
            flash('کامند خصوصی با موفقیت حذف شد!', 'success')
        else:
            flash('کامند پیدا نشد!', 'error')
    except Exception as e:
        flash(f'خطا در حذف کامند: {str(e)}', 'error')
    
    return redirect(url_for('private_commands'))

# آمار و گزارشات
@app.route('/stats')
def stats_page():
    try:
        conn = get_db_connection()
        
        # آمار کلی
        stats = {}
        stats['fosh_count'] = conn.execute('SELECT COUNT(*) FROM fosh_list').fetchone()[0]
        stats['enemy_count'] = conn.execute('SELECT COUNT(*) FROM enemy_list').fetchone()[0]
        stats['friend_count'] = conn.execute('SELECT COUNT(*) FROM friend_list').fetchone()[0]
        stats['friend_words_count'] = conn.execute('SELECT COUNT(*) FROM friend_words').fetchone()[0]
        try:
            stats['private_commands_count'] = conn.execute('SELECT COUNT(*) FROM private_commands').fetchone()[0]
            stats['auto_reply_count'] = conn.execute('SELECT COUNT(*) FROM auto_reply_specific').fetchone()[0]
        except:
            stats['private_commands_count'] = 0
            stats['auto_reply_count'] = 0
        
        # فعالیت‌های اخیر
        recent_stats = conn.execute(
            'SELECT action_type, COUNT(*) as count FROM stats GROUP BY action_type ORDER BY count DESC LIMIT 10'
        ).fetchall()
        
        # آمار روزانه
        daily_stats = conn.execute('''
            SELECT DATE(timestamp) as date, COUNT(*) as count 
            FROM stats 
            WHERE timestamp >= datetime('now', '-7 days')
            GROUP BY DATE(timestamp) 
            ORDER BY date DESC
        ''').fetchall()
        
        conn.close()
        
        return render_template('stats.html', 
                             stats=stats, 
                             recent_stats=recent_stats, 
                             daily_stats=daily_stats)
    except Exception as e:
        flash(f'خطا در بارگذاری آمار: {str(e)}', 'error')
        return render_template('stats.html', stats={}, recent_stats=[], daily_stats=[])

# API برای حذف گروهی
@app.route('/api/clear_all', methods=['POST'])
def clear_all():
    table_name = request.json.get('table')
    
    if table_name not in ['fosh_list', 'enemy_list', 'friend_list', 'friend_words', 'private_commands', 'auto_reply_specific']:
        return jsonify({'success': False, 'message': 'جدول نامعتبر'})
    
    try:
        conn = get_db_connection()
        count = conn.execute(f'SELECT COUNT(*) FROM {table_name}').fetchone()[0]
        conn.execute(f'DELETE FROM {table_name}')
        conn.commit()
        conn.close()
        
        return jsonify({'success': True, 'message': f'{count} مورد حذف شد'})
    except Exception as e:
        return jsonify({'success': False, 'message': f'خطا: {str(e)}'})

# API وضعیت بات
@app.route('/api/bot_status')
def bot_status_api():
    return jsonify({
        'bot_running': check_bot_status(),
        'keep_alive_active': KEEP_ALIVE_ACTIVE,
        'timestamp': datetime.now().isoformat()
    })

if __name__ == '__main__':
    # ایجاد دایرکتوری templates
    os.makedirs('templates', exist_ok=True)
    os.makedirs('static/css', exist_ok=True)
    os.makedirs('static/js', exist_ok=True)
    
    # شروع بات در ابتدا
    start_bot()
    
    app.run(host='0.0.0.0', port=5000, debug=False, threaded=True)
